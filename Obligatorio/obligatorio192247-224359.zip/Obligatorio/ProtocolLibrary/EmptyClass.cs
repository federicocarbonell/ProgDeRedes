﻿using System;
namespace ProtocolLibrary
{
    public static class EmptyClass
    {
        public const int Login = 1;
        public const int ListUsers = 2;
        public const int Message = 3;
    }
}
