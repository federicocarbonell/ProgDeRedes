﻿using System;
namespace ProtocolLibrary
{
    public class Header
    {
        public Header()
        {
        }
    }
}
